import requests
from bs4 import BeautifulSoup
import unicodedata
import logging
import csv
import time
import pandas as pd



class Model():
    def __init__(self):
        """
        Initialize the Model class with basic parameters including request headers, file paths, and logging configuration.
        """
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36'
        }
        self.movie_dct = {}
        self.white_lst = []
        self.url = 'https://www.imdb.com/title/'
        self.movie_csv_path = './ml-latest-small/links.csv'
        self.poster_save_path = './poster'
        self.info_save_path = './info/info.csv'
        self.movie_url_info_path = './info/movie_url_info.csv'  # New path for movie URL information

        # Logging configuration
        logging.basicConfig(filename="run.log", filemode="a+", format="%(asctime)s %(name)s:%(levelname)s:%(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S", level=logging.INFO)

        # Current processing movie ID and IMDB ID
        self.cur_movie_id = None
        self.cur_imdb_id = None

        # ... (other methods remain unchanged)

    def save_movie_url_info(self, movie_id, poster_url, source_url):
        """
        Save the movie ID, poster URL, and source URL to a CSV file.
        """
        with open(self.movie_url_info_path, 'a+', encoding='utf-8', newline='') as fb:
            writer = csv.writer(fb)
            writer.writerow([movie_id, poster_url, source_url])

    def process_html(self, html):
        """
        Parse the HTML content to extract movie information and poster URL, and save them to a CSV file.
        """
        soup = BeautifulSoup(html, 'lxml')
        # Get movie name and release date
        name = soup.find(class_='title_wrapper').h1.get_text()
        name = unicodedata.normalize('NFKC', name)  # Normalize name
        poster_url = ''
        try:
            # Get poster URL
            poster_url = soup.find(class_='poster').a.img['src']
            poster_re = self.get_url_response(poster_url)
            self.save_poster(self.cur_movie_id, poster_re.content)
        except AttributeError:
            self.update_black_lst(self.cur_movie_id, '2')  # Update black list if no poster

        # Extract movie basic information
        info = []
        try:
            info.append(soup.find(class_='subtext').time.get_text().strip())  # Movie duration
        except AttributeError:
            info.append('')
        for tag in soup.find(class_='subtext').find_all('a'):
            info.append(tag.get_text().strip())

        # Extract synopsis
        intro = soup.find(class_='summary_text').get_text().strip()
        intro = unicodedata.normalize('NFKC', intro)

        # Extract cast information including director (D), writer (W), and stars (S)
        case_dict = {'D': [], 'W': [], 'S': [], 'C': []}
        for tags in soup.find_all(class_='credit_summary_item'):
            for h4 in tags.find_all('h4'):
                title = h4.get_text()
                ch = title[0]  # First letter of the cast type
                for a in h4.next_siblings:
                    if a.name == 'a':
                        case_dict[ch].append(a.get_text())

        # Remove extra cast information
        for k, v in case_dict.items():
            if v and (v[-1].find('credit') != -1 or v[-1].find('full cast') != -1):
                case_dict[k] = case_dict[k][:-1]
        if 'C' in case_dict.keys():
            case_dict['D'].extend(case_dict['C'])

        # Save movie details
        detail = [self.cur_movie_id, name, poster_url, info[0], '|'.join(info[1:-1]), info[-1], intro,
                  '|'.join(case_dict['D']), '|'.join(case_dict['W']), '|'.join(case_dict['S'])]
        self.save_info(detail)

        # Save movie URL info
        self.save_movie_url_info(self.cur_movie_id, poster_url, self.url + 'tt' + self.cur_imdb_id)

    def get_white_lst(self):
        """
        从 'white_list' 文件中读取已处理完的电影ID，并将其加入到 white_lst 列表中。
        """
        with open('white_list') as fb:
            for line in fb:
                line = line.strip()
                self.white_lst.append(line)

    def get_movie_id(self):
        """
        从CSV文件中读取电影ID和IMDB ID，存入字典 movie_dct，格式为 {movie_id: imdb_id}。

        输入:
        - self.movie_csv_path: 存储电影和IMDB ID映射的CSV文件路径

        输出:
        - self.movie_dct: 更新后的电影和IMDB ID映射字典。
        """
        with open(self.movie_csv_path) as fb:
            fb.readline()  # 跳过标题行
            for line in fb:
                line = line.strip()
                line = line.split(',')
                # 将电影ID和IMDB ID存入字典
                self.movie_dct[line[0]] = line[1]

    def update_white_lst(self, movie_id):
        """
        将处理过的电影ID加入到 'white_list' 文件中，避免重复处理。

        输入:
        - movie_id: 已处理的电影ID。
        """
        with open('white_list', 'a+') as fb:
            fb.write(movie_id + '\n')

    def update_black_lst(self, movie_id, msg=''):
        """
        更新黑名单 'black_list' 文件，记录处理失败的电影ID，并附加错误信息。

        输入:
        - movie_id: 处理失败的电影ID。
        - msg: 错误信息，'1' 表示URL失效，'2' 表示没有海报。
        """
        with open('black_list', 'a+') as fb:
            fb.write(movie_id + ' ' + self.movie_dct[movie_id] + ' ' + msg + '\n')

    def get_url_response(self, url):
        """
        发送网页请求，获取电影详情页的响应。设置最多重试5次。

        输入:
        - url: 要访问的电影详情URL。

        输出:
        - 返回网页响应内容，如果失败返回 None。
        """
        logging.info(f'get {url}')
        i = 0
        while i < 5:
            try:
                response = requests.get(url, headers=self.headers, timeout=6)
                if response.status_code == 200:
                    logging.info(f'get {url} success')
                    return response
                logging.error(f'get {url} status_code error: {response.status_code} movie_id is {self.cur_movie_id}')
                return None
            except requests.RequestException:
                logging.error(f'get {url} error, try to restart {i + 1}')
                i += 1
        return None


    def save_poster(self, movie_id, content):
        """
        将下载的电影海报保存到指定路径。

        输入:
        - movie_id: 电影ID。
        - content: 海报的二进制内容。
        """
        with open(f'{self.poster_save_path}/{movie_id}.jpg', 'wb') as fb:
            fb.write(content)

    def save_info(self, detail):
        """
        将电影的详细信息保存到CSV文件。

        输入:
        - detail: 包含电影详细信息的列表。
        """
        with open(f'{self.info_save_path}', 'a+', encoding='utf-8', newline='') as fb:
            writer = csv.writer(fb)
            writer.writerow(detail)

    def run(self):
        """
        Main execution function to crawl movie information. Reads white list, gets movie IDs, and fetches their details.
        """
        self.get_white_lst()
        self.get_movie_id()
        for movie_id, imdb_id in self.movie_dct.items():
            if movie_id in self.white_lst:
                continue
            self.cur_movie_id = movie_id
            self.cur_imdb_id = imdb_id
            time.sleep(1)  # Avoid triggering anti-scraping mechanism
            response = self.get_url_response(self.url + 'tt' + self.cur_imdb_id)
            if response is None:
                self.save_info([self.cur_movie_id, '' * 9])  # For failed movies
                self.update_white_lst(self.cur_movie_id)
                self.update_black_lst(self.cur_movie_id, '1')
                continue
            self.process_html(response.content)
            self.update_white_lst(self.cur_movie_id)
            logging.info(f'process movie {self.cur_movie_id} success')



if __name__ == '__main__':
    s = Model()
    s.run()
    print('done')

