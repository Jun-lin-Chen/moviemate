import pandas as pd

# 读取CSV文件
df = pd.read_csv('./ml-latest-small/links.csv')

# 更新imdbId列
df['imdbId'] = 'https://www.imdb.com/title/tt' + df['imdbId'].astype(str)

# 保存更新后的CSV文件
df.to_csv('movies_url.csv', index=False)
