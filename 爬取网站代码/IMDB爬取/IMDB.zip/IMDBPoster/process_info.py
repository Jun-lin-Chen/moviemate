import csv


def process_genre():
    """
    处理电影的类型（genre），从CSV文件中读取电影类型数据并将不同的类型提取出来，保存到一个文本文件中。

    输入:
    无显式参数。函数内部会从硬编码的路径 'IMDBPoster/info/info.csv' 读取数据。

    输出:
    一个名为 'info/genre.txt' 的文本文件，包含所有不重复的电影类型，每个类型一行。

    文件说明:
    - 'IMDBPoster/info/info.csv': 包含电影信息的CSV文件。
    - 'info/genre.txt': 输出的文本文件，用来存储提取到的电影类型（每行一个类型）。
    """

    # 定义CSV文件路径
    path = 'IMDBPoster/info/info.csv'

    # 打开CSV文件进行读取，同时打开输出的文本文件用于写入
    with open(path, encoding='utf-8') as fb, open('info/genre.txt', 'w') as wfb:

        # 读取CSV文件的内容
        reader = csv.reader(fb)

        # 跳过CSV文件的标题行
        title = reader.__next__()

        # 使用集合存储所有出现的电影类型，避免重复
        genre_set = set()

        # 遍历CSV文件的每一行
        for line in reader:
            # 如果该行的第5列（电影类型列）非空
            if line[4]:
                # 将类型字段按 '|' 分隔，并将结果更新到集合中
                genre_set.update(line[4].split('|'))

        # 将集合中的类型写入到输出文件，每行写一个类型
        for g in genre_set:
            wfb.write(g + '\n')

    # 空的 pass 用于表示函数结尾
    pass


# 主函数的入口，调用 process_genre 函数
if __name__ == '__main__':
    process_genre()
    pass
